from flask import Flask, render_template, request

app = Flask(__name__)

# 言語テキスト辞書
texts = {
    'ja': {
        'title': 'こんにちは世界',
        'welcome': 'ようこそ！これは言語切り替えデモです。',
        'description': 'URLに"?lang=en"を追加すると英語に切り替わります。',
        'button': '続ける'
    },
    'en': {
        'title': 'Hello World',
        'welcome': 'Welcome! This is a language switching demo.',
        'description': 'Add "?lang=en" to the URL to switch to English.',
        'button': 'Continue'
    }
}

@app.route('/')
def index():
    # GETパラメータからlang値を取得（デフォルトはja）
    lang = request.args.get('lang', 'ja')
    # 有効な言語コードのみ許可
    lang = lang if lang in ['en', 'ja'] else 'ja'
    
    # 選択された言語のテキストを取得
    current_texts = texts[lang]
    
    # テンプレートに言語とテキストを渡す
    return render_template('index.html', lang=lang, texts=current_texts)

if __name__ == '__main__':
    app.run(debug=True)