シンプルなPythonコードで、URLパラメータの"lang=en"を使って言語を切り替えるデモを作成します。以下はFlaskを使った最小限の実装です：

```python
from flask import Flask, render_template, request

app = Flask(__name__)

# 言語テキスト辞書
texts = {
    'ja': {
        'title': 'こんにちは世界',
        'welcome': 'ようこそ！これは言語切り替えデモです。',
        'description': 'URLに"?lang=en"を追加すると英語に切り替わります。',
        'button': '続ける'
    },
    'en': {
        'title': 'Hello World',
        'welcome': 'Welcome! This is a language switching demo.',
        'description': 'Add "?lang=en" to the URL to switch to English.',
        'button': 'Continue'
    }
}

@app.route('/')
def index():
    # GETパラメータからlang値を取得（デフォルトはja）
    lang = request.args.get('lang', 'ja')
    # 有効な言語コードのみ許可
    lang = lang if lang in ['en', 'ja'] else 'ja'
    
    # 選択された言語のテキストを取得
    current_texts = texts[lang]
    
    # テンプレートに言語とテキストを渡す
    return render_template('index.html', lang=lang, texts=current_texts)

if __name__ == '__main__':
    app.run(debug=True)
```

HTMLテンプレート例（templates/index.html）:

```html
<!DOCTYPE html>
<html lang="{{ lang }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ texts.title }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .container {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 5px;
        }
        .lang-switch {
            text-align: right;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="lang-switch">
        {% if lang == 'en' %}
            <a href="/">日本語</a>
        {% else %}
            <a href="/?lang=en">English</a>
        {% endif %}
    </div>
    
    <div class="container">
        <h1>{{ texts.title }}</h1>
        <p>{{ texts.welcome }}</p>
        <p>{{ texts.description }}</p>
        <button>{{ texts.button }}</button>
    </div>
</body>
</html>
```

これは最も基本的な実装です。リンクをクリックすると言語が切り替わります。

# Flaskを使った言語切り替えデモの設定と起動方法

この言語切り替えデモを実行するための環境設定と起動手順です。

## 環境設定

1. **Python 3のインストール**
   * [Python公式サイト](https://www.python.org/downloads/)からPython 3.8以上をインストール

2. **仮想環境の作成**（推奨）
   ```bash
   # 仮想環境を作成
   python -m venv venv

   # 仮想環境を有効化
   # Windows:
   venv\Scripts\activate
   # Mac/Linux:
   source venv/bin/activate
   ```

3. **Flaskのインストール**
   ```bash
   pip install flask
   ```

## プロジェクト構成を作成

1. **プロジェクトフォルダを作成**
   ```bash
   mkdir lang_demo
   cd lang_demo
   ```

2. **必要なファイルとフォルダを作成**
   ```bash
   mkdir templates
   touch app.py
   ```

3. **`app.py`にコードを貼り付け**
   * 先ほど紹介したPythonコード全体をapp.pyに貼り付けます

4. **`templates`フォルダにHTMLファイルを作成**
   ```bash
   touch templates/index.html
   ```
   * 先ほど紹介したHTMLコードをindex.htmlに貼り付けます

## 起動方法

1. **アプリケーションを起動**
   ```bash
   # 仮想環境が有効化されていることを確認してから
   python app.py
   ```

2. **ウェブブラウザでアクセス**
   * 日本語版: http://127.0.0.1:5000/
   * 英語版: http://127.0.0.1:5000/?lang=en

## トラブルシューティング

- **ポート5000が使用中の場合**：app.pyを編集して別のポートを指定
  ```python
  if __name__ == '__main__':
      app.run(debug=True, port=8000)  # ポート8000に変更
  ```

- **テンプレートが見つからないエラー**：プロジェクト構成を確認
  * templates/index.htmlが正しい場所に存在するか
  * ファイル名とパスが正確か

- **モジュールが見つからないエラー**：Flaskがインストールされているか確認
  ```bash
  pip list | grep Flask
  ```

## 応用：本番環境での実行

本番環境で実行する場合は、Gunicornなどの本番用WSGIサーバーを使用することをお勧めします：

```bash
pip install gunicorn
gunicorn app:app
```

以上で、シンプルな言語切り替えデモアプリケーションを実行できます。言語を切り替えるには、URLに「?lang=en」を追加するか、ページ上部の言語切り替えリンクをクリックします。


# Flaskアプリケーションのフォルダ構成

シンプルな言語切り替えデモアプリケーションのフォルダ構成は以下のようになります：

```
lang_demo/                  # プロジェクトのルートディレクトリ
│
├── app.py                  # メインのFlaskアプリケーションファイル
│
├── templates/              # HTMLテンプレートを格納するフォルダ
│   └── index.html         # メインページのHTMLテンプレート
│
└── venv/                   # 仮想環境フォルダ (オプション)
```

## 詳細説明

- **lang_demo** - プロジェクトの最上位フォルダです。名前は任意で変更できます。
- **app.py** - アプリケーションのメインファイルで、Flaskの設定とルート定義、言語テキスト管理などが含まれます。
- **templates** - Flaskがテンプレートを探すデフォルトのフォルダです。この名前は変更しないでください。
- **index.html** - メインページのHTMLテンプレートです。
- **venv** - Python仮想環境フォルダ。この名前は変更可能です。

これだけの構成で言語切り替えデモアプリケーションを実行できます。静的ファイル（CSSやJavaScriptなど）を追加する場合は、`static`フォルダを作成します：

```
lang_demo/
│
├── app.py
│
├── templates/
│   └── index.html
│
├── static/                 # 静的ファイル用フォルダ（必要に応じて）
│   └── style.css          # CSSファイル
│
└── venv/
```
シンプルなPythonコードで、URLパラメータの"lang=en"を使って言語を切り替えるデモを作成します。以下はFlaskを使った最小限の実装です：

```python
from flask import Flask, render_template, request

app = Flask(__name__)

# 言語テキスト辞書
texts = {
    'ja': {
        'title': 'こんにちは世界',
        'welcome': 'ようこそ！これは言語切り替えデモです。',
        'description': 'URLに"?lang=en"を追加すると英語に切り替わります。',
        'button': '続ける'
    },
    'en': {
        'title': 'Hello World',
        'welcome': 'Welcome! This is a language switching demo.',
        'description': 'Add "?lang=en" to the URL to switch to English.',
        'button': 'Continue'
    }
}

@app.route('/')
def index():
    # GETパラメータからlang値を取得（デフォルトはja）
    lang = request.args.get('lang', 'ja')
    # 有効な言語コードのみ許可
    lang = lang if lang in ['en', 'ja'] else 'ja'
    
    # 選択された言語のテキストを取得
    current_texts = texts[lang]
    
    # テンプレートに言語とテキストを渡す
    return render_template('index.html', lang=lang, texts=current_texts)

if __name__ == '__main__':
    app.run(debug=True)
```

HTMLテンプレート例（templates/index.html）:

```html
<!DOCTYPE html>
<html lang="{{ lang }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ texts.title }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .container {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 5px;
        }
        .lang-switch {
            text-align: right;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="lang-switch">
        {% if lang == 'en' %}
            <a href="/">日本語</a>
        {% else %}
            <a href="/?lang=en">English</a>
        {% endif %}
    </div>
    
    <div class="container">
        <h1>{{ texts.title }}</h1>
        <p>{{ texts.welcome }}</p>
        <p>{{ texts.description }}</p>
        <button>{{ texts.button }}</button>
    </div>
</body>
</html>
```

これは最も基本的な実装です。リンクをクリックすると言語が切り替わります。





